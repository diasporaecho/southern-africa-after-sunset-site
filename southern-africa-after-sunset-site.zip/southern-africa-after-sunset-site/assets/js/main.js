const fallbackTrip = {
  tripTitle: "Southern Africa After Sunset",
  tagline: "A family-friendly preview of a solo Southern Africa journey built around city lights, waterfalls, safari water, and golden-hour coastlines.",
  generalDates: "Dec 29, 2026 – Jan 11, 2027",
  departureDate: "2026-12-29",
  countries: [
    { name: "South Africa", emoji: "🇿🇦" },
    { name: "Zimbabwe", emoji: "🇿🇼" },
    { name: "Zambia", emoji: "🇿🇲" },
    { name: "Botswana", emoji: "🇧🇼" }
  ],
  routeOrder: "Johannesburg / Rosebank → Victoria Falls, Zimbabwe → Livingstone, Zambia → Kasane / Chobe → Maun / Okavango → Cape Town",
  backupRoute: "If the return flight must stay from Johannesburg: Cape Town → Johannesburg with a large same-day buffer. If Kasane → Maun logistics do not work cleanly: save Okavango for a future Botswana trip and continue from Chobe to Cape Town.",
  airportStrategy: "Arrive in Johannesburg. Prefer departing from Cape Town if the price and schedule work. Backup: keep a Johannesburg return and fly Cape Town → Johannesburg early with a safe buffer.",
  route: [],
  homeBases: [],
  galleryPlaceholders: ["Replace with your photo."],
  playlist: { name: "Southern Africa After Sunset", mood: ["golden-hour", "safari sunrise", "Cape coastline"] }
};

const state = {
  trip: fallbackTrip,
  countdownTimer: null
};

const qs = (selector, scope = document) => scope.querySelector(selector);
const qsa = (selector, scope = document) => [...scope.querySelectorAll(selector)];

function setText(selector, value) {
  const element = qs(selector);
  if (element && value) element.textContent = value;
}

async function loadTripData() {
  try {
    const response = await fetch("data/trip.json", { cache: "no-store" });
    if (!response.ok) throw new Error("Trip data could not be loaded.");
    state.trip = await response.json();
  } catch (error) {
    console.warn("Using fallback trip data:", error);
    state.trip = fallbackTrip;
  }

  renderStaticContent();
  renderRouteCards();
  renderHomeBases();
  renderDestinations();
  renderGallery();
  renderPlaylist();
  startCountdown();
}

function renderStaticContent() {
  const trip = state.trip;
  setText("[data-trip-tagline]", trip.tagline);
  setText("[data-general-dates]", trip.generalDates);
  setText("[data-route-order]", trip.routeOrder);
  setText("[data-airport-strategy]", trip.airportStrategy);
  setText("[data-backup-route]", trip.backupRoute);

  const countryText = trip.countries?.map((country) => `${country.emoji} ${country.name}`).join(" · ");
  const metaItems = qsa(".hero-meta span");
  if (metaItems[1] && countryText) metaItems[1].textContent = countryText;
}

function renderRouteCards() {
  const wrapper = qs("[data-route-cards]");
  if (!wrapper) return;

  wrapper.innerHTML = state.trip.route.map((stop, index) => `
    <article class="route-card ${index === 0 ? "is-open" : ""}">
      <button class="route-card-header" type="button" aria-expanded="${index === 0 ? "true" : "false"}">
        <span class="route-number">${stop.order}</span>
        <span>
          <h3>${stop.city}</h3>
          <small>${stop.country} · ${stop.dates} · ${stop.nights} night${stop.nights === 1 ? "" : "s"}</small>
        </span>
        <span class="route-toggle-icon" aria-hidden="true">+</span>
      </button>
      <div class="route-card-body">
        <p><strong>Role:</strong> ${stop.role}</p>
        <p>${stop.description}</p>
        <p><strong>Travel flow:</strong> ${stop.travelFlow}</p>
      </div>
    </article>
  `).join("");
}

function renderHomeBases() {
  const wrapper = qs("[data-home-bases]");
  if (!wrapper) return;

  wrapper.innerHTML = state.trip.homeBases.map((base) => `
    <article class="home-base-card">
      <p class="country">${base.country}</p>
      <h3>${base.city}</h3>
      <p><strong>${base.showHotelName ? "Hotel" : "Area / vibe"}:</strong> ${base.areaOrVibe}</p>
      <p><strong>Neighborhood:</strong> ${base.neighborhood}</p>
      <p>${base.notes}</p>
      <span class="badge">Public-safe display</span>
    </article>
  `).join("");
}

function renderDestinations() {
  const wrapper = qs("[data-destinations]");
  if (!wrapper) return;

  wrapper.innerHTML = state.trip.route.map((stop) => {
    const h = stop.highlights;
    return `
      <article class="destination-card">
        <p class="country">${stop.country}</p>
        <h3>${stop.city}</h3>
        <p>${stop.description}</p>
        <ul>
          <li><strong>Main vibe:</strong> ${h.mainVibe}</li>
          <li><strong>Food / culture:</strong> ${h.foodCultureMoment}</li>
          <li><strong>Photo moment:</strong> ${h.photoMoment}</li>
          <li><strong>Evening vibe:</strong> ${h.eveningCityLightVibe}</li>
          <li><strong>Wow:</strong> ${h.wowExperience}</li>
        </ul>
      </article>
    `;
  }).join("");
}

function renderGallery() {
  const wrapper = qs("[data-gallery]");
  if (!wrapper) return;

  wrapper.innerHTML = state.trip.galleryPlaceholders.map((label, index) => `
    <button class="gallery-card" type="button" data-lightbox-trigger data-title="${escapeHtml(label)}">
      <span>Photo ${String(index + 1).padStart(2, "0")}</span>
      <strong>${label}</strong>
      <span>Replace with your photo.</span>
    </button>
  `).join("");
}

function renderPlaylist() {
  const playlist = state.trip.playlist || fallbackTrip.playlist;
  setText("[data-playlist-name]", playlist.name);

  const wrapper = qs("[data-mood-chips]");
  if (!wrapper) return;
  wrapper.innerHTML = playlist.mood.map((mood) => `<span>${mood}</span>`).join("");
}

function startCountdown() {
  const departureDate = new Date(`${state.trip.departureDate}T00:00:00`);
  const fields = {
    days: qs("[data-days]"),
    hours: qs("[data-hours]"),
    minutes: qs("[data-minutes]"),
    seconds: qs("[data-seconds]")
  };

  function update() {
    const now = new Date();
    let diff = departureDate.getTime() - now.getTime();

    if (Number.isNaN(diff)) return;
    if (diff < 0) diff = 0;

    const secondsTotal = Math.floor(diff / 1000);
    const days = Math.floor(secondsTotal / 86400);
    const hours = Math.floor((secondsTotal % 86400) / 3600);
    const minutes = Math.floor((secondsTotal % 3600) / 60);
    const seconds = secondsTotal % 60;

    fields.days.textContent = String(days);
    fields.hours.textContent = String(hours).padStart(2, "0");
    fields.minutes.textContent = String(minutes).padStart(2, "0");
    fields.seconds.textContent = String(seconds).padStart(2, "0");
  }

  update();
  if (state.countdownTimer) clearInterval(state.countdownTimer);
  state.countdownTimer = setInterval(update, 1000);
}

function setupMobileMenu() {
  const toggle = qs("[data-menu-toggle]");
  const nav = qs("[data-nav]");
  if (!toggle || !nav) return;

  toggle.addEventListener("click", () => {
    const isOpen = nav.classList.toggle("is-open");
    document.body.classList.toggle("menu-open", isOpen);
    toggle.setAttribute("aria-expanded", String(isOpen));
  });

  nav.addEventListener("click", (event) => {
    if (event.target.matches("a")) {
      nav.classList.remove("is-open");
      document.body.classList.remove("menu-open");
      toggle.setAttribute("aria-expanded", "false");
    }
  });
}

function setupRouteCards() {
  document.addEventListener("click", (event) => {
    const button = event.target.closest(".route-card-header");
    if (!button) return;

    const card = button.closest(".route-card");
    const isOpen = card.classList.toggle("is-open");
    button.setAttribute("aria-expanded", String(isOpen));
  });
}

function setupCopyLink() {
  const button = qs("[data-copy-link]");
  const status = qs("[data-copy-status]");
  if (!button || !status) return;

  button.addEventListener("click", async () => {
    const link = window.location.href.split("#")[0];
    try {
      await navigator.clipboard.writeText(link);
      status.textContent = "Copied.";
    } catch (error) {
      status.textContent = "Copy manually from the address bar.";
    }

    window.setTimeout(() => {
      status.textContent = "";
    }, 2600);
  });
}

function setupLightbox() {
  const lightbox = qs("[data-lightbox]");
  const title = qs("[data-lightbox-title]");
  const closeButton = qs("[data-lightbox-close]");
  if (!lightbox || !title || !closeButton) return;

  function openLightbox(text) {
    title.textContent = `${text}: Replace with your photo.`;
    lightbox.classList.add("is-open");
    lightbox.setAttribute("aria-hidden", "false");
    closeButton.focus();
  }

  function closeLightbox() {
    lightbox.classList.remove("is-open");
    lightbox.setAttribute("aria-hidden", "true");
  }

  document.addEventListener("click", (event) => {
    const trigger = event.target.closest("[data-lightbox-trigger]");
    if (trigger) {
      openLightbox(trigger.dataset.title || "Replace with your photo");
    }
  });

  closeButton.addEventListener("click", closeLightbox);
  lightbox.addEventListener("click", (event) => {
    if (event.target === lightbox) closeLightbox();
  });

  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape") closeLightbox();
  });
}

function escapeHtml(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function init() {
  setupMobileMenu();
  setupRouteCards();
  setupCopyLink();
  setupLightbox();
  loadTripData();
}

document.addEventListener("DOMContentLoaded", init);
